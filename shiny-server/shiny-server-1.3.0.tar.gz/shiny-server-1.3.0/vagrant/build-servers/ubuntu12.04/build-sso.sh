
# Clone the repository from GitHub
git clone https://github.com/rstudio/shiny-server.git
cd shiny-server

git remote add trestle https://github.com/trestletech/shiny-server.git

./make-package.sh

